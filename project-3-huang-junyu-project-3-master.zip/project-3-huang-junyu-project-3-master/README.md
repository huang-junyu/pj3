# project-3-starter
Project 3: raytracer

Group members:

Junyu Huang huang.junyu@csu.fullerton.edu
